# LV2-RMA

An application that enables the display of information about inspiriting people from the world of computing
